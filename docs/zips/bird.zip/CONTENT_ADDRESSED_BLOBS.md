# Content-Addressed Blob Storage for BIRD

## Executive Summary

This document describes adding **content-addressed storage** to BIRD (Build Information Recordkeeper and Database) to achieve 70-90% storage savings through automatic deduplication.

**Key Idea:** Instead of storing each command output with a unique UUID filename, store blobs by their content hash (BLAKE3). Identical outputs share the same blob file.

## The Problem

Current BIRD storage (UUID-based):
```
managed/
├── a1b2c3d4-uuid1.bin.zst    # make test run 1
├── e5f6g7h8-uuid2.bin.zst    # make test run 2 (identical output!)
├── i9j0k1l2-uuid3.bin.zst    # make test run 3 (identical output!)
└── ...                        # 100 more identical outputs
```

**Problem:** 100 identical test outputs = 100 separate files = 100× storage.

## The Solution

Content-addressed storage:
```
blobs/content/
├── ab/
│   └── abc123def456...789.bin.gz    # Shared by all 100 runs!
├── cd/
└── ...
```

**Solution:** 100 identical test outputs = 1 shared blob + 100 references = 1× storage.

## Architecture

### Before: UUID-based

```
┌─────────────┐
│  Command 1  │──────┐
└─────────────┘      │
                     ├──> managed/uuid1.bin.zst (5MB)
┌─────────────┐      │
│  Command 2  │──────┘     (identical content)
└─────────────┘

Storage: 10MB (2 × 5MB)
```

### After: Content-addressed

```
┌─────────────┐
│  Command 1  │────┐
└─────────────┘    │
                   ├──> blobs/content/ab/abc123...789.bin.gz (5MB)
┌─────────────┐    │
│  Command 2  │────┘
└─────────────┘

Storage: 5MB (1 × 5MB, 2 references)
Savings: 50%
```

## Schema Changes

### Old: outputs table
```sql
CREATE TABLE outputs (
    id              UUID,
    command_id      UUID,
    stream          TEXT,
    content         BLOB,      -- <1MB inline
    file_ref        TEXT,      -- ≥1MB path to managed/uuid.bin.zst
    byte_length     BIGINT,
    ...
);
```

### New: outputs table
```sql
CREATE TABLE outputs (
    id              UUID,
    command_id      UUID,
    stream          TEXT,
    
    -- NEW: Content identification
    content_hash    TEXT NOT NULL,     -- BLAKE3 hash (hex)
    byte_length     BIGINT NOT NULL,
    
    -- NEW: Polymorphic storage
    storage_type    TEXT NOT NULL,     -- 'inline', 'blob', 'archive'
    storage_ref     TEXT NOT NULL,     -- URI to content
    
    ...
);
```

### New: blob_registry table
```sql
CREATE TABLE blob_registry (
    content_hash      TEXT PRIMARY KEY,
    byte_length       BIGINT NOT NULL,
    ref_count         INT DEFAULT 0,      -- How many outputs reference this
    first_seen        TIMESTAMP,
    last_accessed     TIMESTAMP,
    storage_tier      TEXT,               -- 'recent', 'archive'
    storage_path      TEXT,               -- Relative path from BIRD_ROOT
    verified_at       TIMESTAMP,
    corrupt           BOOLEAN DEFAULT FALSE
);
```

## Storage Types

### 1. Inline (<1MB)
Small outputs stored directly in parquet files as data: URIs.

```
storage_type: 'inline'
storage_ref:  'data:application/octet-stream;base64,SGVsbG8gV29ybGQh'
```

**Why:** Avoids filesystem overhead for tiny files.

### 2. Blob (≥1MB, recent)
Large outputs stored in content-addressed blobs.

```
storage_type: 'blob'
storage_ref:  'file://recent/blobs/content/ab/abc123def456...789.bin.gz'
```

**Why:** Automatic deduplication + fast access.

### 3. Archive (≥1MB, old)
Moved to archive tier after N days.

```
storage_type: 'archive'
storage_ref:  'file://archive/blobs/content/ab/abc123def456...789.bin.gz'
```

**Why:** Cheaper storage, still deduplicated.

## Deduplication Flow

### Capture (Write)

```rust
fn write_output(content: &[u8]) -> Result<()> {
    // 1. Hash it
    let hash = blake3::hash(content);
    
    // 2. Check if blob exists
    if let Some(existing) = blob_registry.get(&hash)? {
        // DEDUP HIT: Reuse existing blob
        blob_registry.increment_ref_count(&hash)?;
        outputs.insert(storage_ref: existing.path);
    } else {
        // DEDUP MISS: Write new blob
        let path = write_blob(&hash, content)?;
        blob_registry.insert(&hash, path, ref_count: 1)?;
        outputs.insert(storage_ref: path);
    }
}
```

### Query (Read)

```rust
fn get_output(command_id: UUID) -> Result<Vec<u8>> {
    // 1. Get storage reference
    let (storage_type, storage_ref) = outputs.get(command_id)?;
    
    // 2. Resolve based on type
    match storage_type {
        "inline" => decode_data_uri(storage_ref),
        "blob" | "archive" => {
            let path = parse_file_uri(storage_ref);
            decompress_gzip(path)
        }
    }
}
```

## Directory Structure

```
$BIRD_ROOT/db/data/
├── recent/
│   ├── commands/
│   │   └── date=YYYY-MM-DD/*.parquet
│   ├── outputs/
│   │   └── date=YYYY-MM-DD/*.parquet
│   └── blobs/
│       └── content/              # Content-addressed pool
│           ├── 00/               # First 2 hex chars of hash
│           │   └── 00abc123...def.bin.gz
│           ├── 01/
│           ├── 02/
│           ├── ...
│           └── ff/               # 256 subdirectories total
└── archive/
    └── blobs/
        └── content/              # Global pool (not date-partitioned!)
            ├── 00/
            ├── 01/
            └── ...
```

**Why subdirectories?** Most filesystems slow down with >10k files in one directory. By using first 2 hex chars (256 subdirs), each subdir has ~N/256 files.

## Hash Algorithm: BLAKE3

**Why BLAKE3?**
- **Fast:** 3 GB/s on modern CPUs (vs SHA-256: 200 MB/s)
- **Secure:** Cryptographically secure (collision resistance)
- **Simple:** Single canonical output (no different modes)

**Performance:**
- 5MB output: ~1.7ms to hash
- Negligible overhead in non-critical path

**Collision risk:** Astronomically low (2^-256), not a concern for this use case.

## Compression: gzip

**Why gzip over zstd?**
- **DuckDB compatible:** Can read `.gz` files directly
- **Universal:** Available everywhere
- **Good enough:** ~2-3× compression for text

**Trade-off:** Slightly worse compression than zstd, but eliminates decompression step for queries.

```sql
-- DuckDB can read directly!
SELECT * FROM read_json('output.json.gz');
```

## Garbage Collection

### Strategy 1: Never Delete (MVP)
- Simplest implementation
- Storage is cheap
- Keeps full history forever

### Strategy 2: Reference Counting (Production)
```sql
-- When deleting an output
DELETE FROM outputs WHERE id = ?;

-- Decrement ref_count
UPDATE blob_registry 
SET ref_count = ref_count - 1 
WHERE content_hash = ?;

-- Delete unreferenced blobs
DELETE FROM blob_registry WHERE ref_count = 0;
```

### Strategy 3: Mark-and-Sweep (Maintenance)
```bash
# Mark phase: Find all referenced hashes
SELECT DISTINCT content_hash FROM outputs INTO referenced_hashes;

# Sweep phase: Delete unreferenced
DELETE FROM blob_registry 
WHERE content_hash NOT IN referenced_hashes;
```

## Storage Savings Analysis

### Example 1: CI Pipeline (100 test runs)

**Workload:**
- 100 identical test runs
- 5MB output per run
- 100% duplication (same tests)

**Before (UUID):**
- Storage: 100 × 5MB = 500MB
- Files: 100 unique blobs

**After (Content-addressed):**
- Storage: 1 × 5MB = 5MB
- Files: 1 blob, 100 references
- **Savings: 495MB (99%)**

### Example 2: Daily Development (10K commands)

**Workload:**
- 10,000 commands/day
- 200KB avg output
- 80% duplication (similar builds)

**Before (UUID):**
- Storage: 10k × 200KB = 2GB/day
- Monthly: 60GB

**After (Content-addressed):**
- Unique content: 20% × 2GB = 400MB/day
- Monthly: 12GB
- **Savings: 48GB (80%)**

### Example 3: Multiple Clients (3 machines)

**Workload:**
- 3 developers
- Each runs same tests
- Shared BIRD database

**Before (UUID):**
- Each client: 100MB/day
- Total: 300MB/day

**After (Content-addressed):**
- Shared blobs: ~100MB/day
- Total: 100MB/day
- **Savings: 200MB (67%)**

## Performance Impact

### Overhead per Capture

```
Hash computation (BLAKE3):  1.7ms  (5MB @ 3GB/s)
Dedup check (SQL query):    0.5ms  (indexed lookup)
Ref count update (SQL):     0.5ms  (single UPDATE)
─────────────────────────────────
Total overhead:             2.7ms
```

**Acceptable:** This is non-critical path (after command completes).

### Query Performance

**No regression:** Decompression time is the same (gzip vs zstd ~similar).

**Potential speedup:** If blob is already in OS page cache (shared by multiple queries), second access is instant.

## Race Conditions

### Concurrent Writes (Same Hash)

Two processes write same content simultaneously:

**Problem:**
```
Process A: write_blob(hash) → /tmp/hash.bin.gz.tmp → rename to hash.bin.gz
Process B: write_blob(hash) → /tmp/hash.bin.gz.tmp → rename to hash.bin.gz
```

**Solution:** Atomic rename handles this!
```rust
// Process A wins
fs::rename(temp, final)?;  // Success

// Process B loses
fs::rename(temp, final)?;  // Error: AlreadyExists
fs::remove(temp)?;         // Clean up temp file
// Use existing blob (Process A's)
```

**Result:** Both processes end up using the same blob. No data loss.

## Migration Path

### Step 1: Schema Migration
```sql
-- Add new columns (nullable initially)
ALTER TABLE outputs ADD COLUMN content_hash TEXT;
ALTER TABLE outputs ADD COLUMN storage_type TEXT;
ALTER TABLE outputs ADD COLUMN storage_ref TEXT;

-- Create blob registry
CREATE TABLE blob_registry (...);
```

### Step 2: Hash Existing Blobs
```rust
// For each existing file in managed/
for file in fs::read_dir("managed/")? {
    let content = decompress_zstd(file)?;
    let hash = blake3::hash(&content);
    
    // Move to content-addressed location
    let new_path = format!("blobs/content/{:02x}/{}.bin.gz", hash[0], hash);
    compress_gzip(&content, &new_path)?;
    
    // Update outputs table
    db.execute(
        "UPDATE outputs SET content_hash = ?, storage_type = 'blob', storage_ref = ? WHERE file_ref = ?",
        (hash, new_path, file.name())
    )?;
}
```

### Step 3: Build Blob Registry
```sql
INSERT INTO blob_registry (content_hash, byte_length, ref_count, storage_path)
SELECT 
    content_hash,
    byte_length,
    COUNT(*) as ref_count,
    FIRST(storage_ref) as storage_path
FROM outputs
WHERE storage_type = 'blob'
GROUP BY content_hash;
```

### Step 4: Cleanup
```bash
# Verify migration
shq verify-blobs

# Remove old managed/ directory
rm -rf db/data/recent/managed/
```

## Testing Strategy

### Unit Tests

1. **Hash consistency**
   ```rust
   assert_eq!(blake3::hash(data1), blake3::hash(data1));
   assert_ne!(blake3::hash(data1), blake3::hash(data2));
   ```

2. **Dedup detection**
   ```rust
   write_output(cmd1, data);
   write_output(cmd2, data);  // Same data
   assert_eq!(count_blobs(), 1);
   assert_eq!(count_outputs(), 2);
   ```

3. **Reference counting**
   ```rust
   write_output(cmd1, data);
   assert_eq!(get_ref_count(hash), 1);
   write_output(cmd2, data);
   assert_eq!(get_ref_count(hash), 2);
   ```

### Integration Tests

1. **Concurrent writes**
   ```rust
   let data = b"test";
   let (cmd1, cmd2) = spawn_concurrent(|| write_output(data));
   assert_eq!(count_blobs(), 1);  // Both use same blob
   ```

2. **Query after dedup**
   ```rust
   write_output(cmd1, data);
   write_output(cmd2, data);
   assert_eq!(get_output(cmd1), data);
   assert_eq!(get_output(cmd2), data);
   ```

### Performance Tests

1. **Hash overhead**
   ```rust
   let data = vec![0u8; 5_000_000];  // 5MB
   let start = Instant::now();
   blake3::hash(&data);
   assert!(start.elapsed() < Duration::from_millis(5));
   ```

2. **Storage savings**
   ```bash
   # Run 100 identical commands
   for i in {1..100}; do shq run make test; done
   
   # Measure
   blobs=$(du -sb blobs/content/ | cut -f1)
   expected=$(stat -f%z outputs/test.txt)
   assert [ $blobs -lt $(( expected * 2 )) ]
   ```

## Rollback Plan

If issues arise during migration:

1. **Keep old managed/ directory** during migration
2. **Dual-write mode:** Write to both UUID and hash-based locations
3. **Feature flag:** `BIRD_USE_CONTENT_ADDRESSED=false` to disable
4. **Rollback command:** `shq migrate rollback` restores old schema

## Security Considerations

### Hash Collisions

**Risk:** Two different outputs produce same hash → data corruption

**Mitigation:**
- BLAKE3 collision probability: 2^-256 (astronomically low)
- Monitor: Log all hash operations, alert on collision (will never happen)
- Recovery: Full data corruption means hash function is broken (replace BLAKE3)

### Content Privacy

**Risk:** Hash reveals content (e.g., rainbow tables for common outputs)

**Mitigation:**
- BIRD is for build logs (not secrets)
- Secrets should be redacted before capture
- Hash is not reversible (unlike compression-based dedup)

## Future Enhancements

### 1. Cross-Machine Deduplication
Share blob registry across machines:
```
Machine A: Writes blob abc123...
Machine B: Checks registry, downloads from A (rsync/http)
Result: Even more savings for distributed teams
```

### 2. Compression Tuning
Per-content-type compression:
```
.json → gzip level 6 (high compression)
.bin  → gzip level 1 (fast)
.txt  → gzip level 4 (balanced)
```

### 3. Tiered Storage
Automatic migration to cheaper storage:
```
0-14 days:  NVMe SSD (blobs/content/)
14-90 days: HDD (archive/blobs/)
>90 days:   S3 Glacier (remote/blobs/)
```

## Conclusion

Content-addressed storage provides:
- ✅ **70-90% storage savings** for typical CI/CD workloads
- ✅ **Automatic deduplication** (no user action required)
- ✅ **Fast hashing** (BLAKE3 @ 3GB/s, <2ms overhead)
- ✅ **Simple implementation** (~200 lines of code)
- ✅ **Backward compatible** (existing queries unchanged)
- ✅ **Safe** (atomic operations, hash collision ~impossible)

The trade-off of 2-3ms per capture is negligible compared to 70-90% storage savings.

**Recommendation:** Implement content-addressed storage for BIRD v2.0.

---

**Author:** BIRD Team  
**Date:** 2026-01-02  
**Status:** Approved for Implementation
